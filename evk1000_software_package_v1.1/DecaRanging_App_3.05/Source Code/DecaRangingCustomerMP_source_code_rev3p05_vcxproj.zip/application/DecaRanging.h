/*! ----------------------------------------------------------------------------
 * @file	DecaRanging.h
 * @brief	
 *
 * @attention
 *
 * Copyright 2013 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 */

#pragma once

#include "resource.h"
